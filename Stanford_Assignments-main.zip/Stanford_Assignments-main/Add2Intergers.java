import acm.program.*;


public class Add2Intergers	extends ConsoleProgram {
	public void run() {
		println ("This program adds two numbers.");
				String n1 = readLine("Enter n1: ");
				String n2 = readLine("Enter n2: ");
				String total = n1 + n2;
				println("Total is " + total + ".");
	}
}
